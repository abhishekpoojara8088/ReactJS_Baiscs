
function TeamFun() {
    return <h1>Function Component.</h1>;
}


export default TeamFun