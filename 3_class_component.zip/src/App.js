import Team from './Components/MyFirstClassComponent';
import TeamFun from './Components/MyFirstFunctionComponent';
import { BrowserRouter, Routes, Route } from "react-router-dom";


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/ClassComponent" element={<Team/>}></Route>
        <Route path="/FunctionalComponent" element={<TeamFun/>}></Route>
      </Routes>
    </BrowserRouter>
    //<>
     // <Team/>
    //   <hr/>
    //   <TeamFun/>
    // </> //ShortEnd Fragment
  );
}

export default App;
